package com.example.renpytranslate

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException

class TranslateJob(
    private val ctx: Context,
    private val tree: Uri,
    private val client: ClaudeClient,
    private val log: (String) -> Unit,
    private val progress: (Int, Int) -> Unit
) {
    private val skipDirs = setOf(
        "images", "audio", "music", "sfx", "sound", "voice", "gui", "fonts", "cache", "saves",
        "tl", "renpy", "python-packages", "lib", "ko_patch", "movies", "videos", "icons"
    )
    private val tokenRe = Regex("""\[[^\[\]]*\]|\{[^{}]*\}|%\(\w+\)\w|%[sdif]""")

    private fun tokens(s: String) = tokenRe.findAll(s).map { it.value }.sorted().toList()
    private fun ok(src: String, t: String) = t.isNotBlank() && tokens(src) == tokens(t)
    private fun fatal(e: ApiException) = e.code in 400..499 && e.code != 429

    suspend fun run() {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: run { log("❌ 폴더를 열 수 없어요"); return }
        val gameDir = if (root.name == "game") root else (root.findFile("game") ?: root)

        log("스크립트(.rpy) 찾는 중…")
        val files = withContext(Dispatchers.IO) { ArrayList<DocumentFile>().also { collect(gameDir, it) } }
        if (files.isEmpty()) {
            log("❌ .rpy 파일이 없어요. .rpyc만 있는 게임은 unrpyc로 복원한 뒤 다시 시도해 주세요.")
            return
        }
        files.sortBy { it.name }

        val all = ArrayList<Line>()
        withContext(Dispatchers.IO) {
            for (f in files) {
                val text = ctx.contentResolver.openInputStream(f.uri)
                    ?.use { it.readBytes().toString(Charsets.UTF_8) } ?: continue
                all += RpyParser.parse(text.removePrefix("\uFEFF"))
            }
        }
        log("대사 ${all.size}줄 발견 (파일 ${files.size}개)")
        if (all.isEmpty()) return

        val firstIdx = LinkedHashMap<String, Int>()
        all.forEachIndexed { i, l -> if (l.text !in firstIdx) firstIdx[l.text] = i }

        val koDir = gameDir.findFile("ko_patch") ?: gameDir.createDirectory("ko_patch")
            ?: run { log("❌ ko_patch 폴더를 만들 수 없어요 (이 폴더에 쓰기 권한이 없어요)"); return }

        val done = LinkedHashMap<String, String>()
        withContext(Dispatchers.IO) { loadDict(koDir, done) }
        val pending = firstIdx.keys.filter { it !in done }
        val total = firstIdx.size
        log("고유 문장 ${total}개 · 이미 번역됨 ${done.size}개 · 남은 것 ${pending.size}개")
        progress(done.size, total)

        val lock = Any()
        var failed = 0
        var sinceSave = 0
        val sem = Semaphore(3)

        try {
            coroutineScope {
                pending.chunked(25).map { chunk ->
                    async(Dispatchers.IO) {
                        sem.withPermit {
                            val first = firstIdx[chunk[0]]!!
                            val ctxLines = all.subList(maxOf(0, first - 4), first)
                            val lines = chunk.map { t -> all[firstIdx[t]!!] }
                            val outs = try {
                                client.translate(ctxLines, lines)
                            } catch (e: ApiException) {
                                if (fatal(e)) throw e
                                null
                            } catch (e: IOException) {
                                null
                            }
                            val result = HashMap<String, String>()
                            if (outs != null) {
                                lines.forEachIndexed { i, l ->
                                    var t: String? = outs[i]
                                    if (t == null || !ok(l.text, t)) {
                                        t = try {
                                            client.translate(emptyList(), listOf(l)).firstOrNull()
                                        } catch (e: ApiException) {
                                            if (fatal(e)) throw e
                                            null
                                        } catch (e: IOException) {
                                            null
                                        }
                                    }
                                    if (t != null && ok(l.text, t)) result[l.text] = t
                                }
                            }
                            synchronized(lock) {
                                done.putAll(result)
                                failed += lines.size - result.size
                                progress(done.size, total)
                                sinceSave++
                                if (sinceSave >= 4) {
                                    sinceSave = 0
                                    saveDict(koDir, done)
                                }
                            }
                        }
                    }
                }.awaitAll()
            }
        } finally {
            withContext(NonCancellable + Dispatchers.IO) {
                if (done.isNotEmpty()) {
                    synchronized(lock) { saveDict(koDir, done) }
                    writePatch(koDir)
                }
            }
        }
        log("✅ 번역 완료: ${done.size}/${total}개")
        if (failed > 0) log("⚠ ${failed}개는 번역에 실패해 영어로 남았어요. 다시 시작하면 그것만 이어서 시도해요.")
        log("게임의 game/ko_patch 폴더가 만들어졌어요. 게임을 실행하면 한국어로 나와요. (되돌리기: ko_patch 폴더 삭제)")
    }

    // ───────── 파일 처리 ─────────

    private fun collect(dir: DocumentFile, out: MutableList<DocumentFile>) {
        for (f in dir.listFiles()) {
            val n = f.name ?: continue
            if (f.isDirectory) {
                if (n.lowercase() !in skipDirs) collect(f, out)
            } else if (n.endsWith(".rpy", ignoreCase = true)) {
                out.add(f)
            }
        }
    }

    private fun loadDict(dir: DocumentFile, into: MutableMap<String, String>) {
        val f = dir.findFile("ko_dict.json") ?: return
        try {
            val txt = ctx.contentResolver.openInputStream(f.uri)
                ?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return
            val o = JSONObject(txt)
            for (k in o.keys()) into[k] = o.getString(k)
        } catch (e: Exception) {
            log("기존 번역 불러오기 실패: ${e.message}")
        }
    }

    private fun saveDict(dir: DocumentFile, map: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v)
        writeFile(dir, "ko_dict.json", o.toString().toByteArray(Charsets.UTF_8))
    }

    private fun writeFile(dir: DocumentFile, name: String, bytes: ByteArray) {
        val f = dir.findFile(name)
            ?: dir.createFile("application/octet-stream", name)
            ?: throw IOException("파일을 만들 수 없어요: $name")
        ctx.contentResolver.openOutputStream(f.uri, "wt")?.use { it.write(bytes) }
    }

    private fun writePatch(koDir: DocumentFile) {
        var font: String? = koDir.listFiles()
            .firstOrNull { it.name?.startsWith("KoreanFont", ignoreCase = true) == true }?.name
        if (font == null) {
            val fontRe = Regex("(?i)(NotoSansCJK|NotoSansKR|NotoSerifCJK|SourceHan|Nanum).*\\.(ttf|otf|ttc)")
            val src = File("/system/fonts").listFiles()
                ?.filter { fontRe.matches(it.name) }
                ?.sortedBy { if (it.name.contains("Regular")) 0 else 1 }
                ?.firstOrNull()
            if (src != null) {
                val name = "KoreanFont." + src.extension
                val out = koDir.createFile("application/octet-stream", name)
                if (out != null) {
                    ctx.contentResolver.openOutputStream(out.uri)?.use { o ->
                        src.inputStream().use { it.copyTo(o) }
                    }
                    font = name
                    log("한글 폰트 복사: ${src.name}")
                }
            }
        }
        val fontName: String = font ?: "KoreanFont.ttf"
        if (font == null) {
            log("⚠ 한글 폰트를 못 찾았어요. ko_patch 폴더에 한글 폰트 파일을 KoreanFont.ttf 이름으로 넣어 주세요 (예: 나눔고딕).")
        }
        writeFile(koDir, "ko_patch.rpy", PATCH.replace("@@FONT@@", fontName).toByteArray(Charsets.UTF_8))
    }

    companion object {
        private val PATCH = """
# Auto-generated by 렌파이 번역기. 되돌리려면 이 ko_patch 폴더를 지우세요.
default persistent.ko_on = True

init 999 python:
    import json, re

    _ko_dict = {}
    try:
        _ko_f = renpy.file("ko_patch/ko_dict.json")
        _ko_dict = json.loads(_ko_f.read().decode("utf-8"))
        _ko_f.close()
    except Exception:
        _ko_dict = {}

    _ko_prev_filter = config.say_menu_text_filter

    def _ko_norm(s):
        return re.sub(r"[ \t]+", " ", s).strip()

    def _ko_filter(s):
        if persistent.ko_on:
            t = _ko_dict.get(s) or _ko_dict.get(_ko_norm(s))
            if t:
                s = "{font=ko_patch/@@FONT@@}" + t + "{/font}"
        if _ko_prev_filter is not None:
            s = _ko_prev_filter(s)
        return s

    config.say_menu_text_filter = _ko_filter
    config.overlay_screens.append("ko_toggle")

screen ko_toggle():
    zorder 190
    textbutton ("{font=ko_patch/@@FONT@@}한{/font}" if persistent.ko_on else "EN"):
        action ToggleField(persistent, "ko_on")
        xalign 1.0
        yalign 0.0
        text_size 22
""".trimStart()
    }
}

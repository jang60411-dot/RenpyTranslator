package com.example.renpytranslate

data class Line(val speaker: String, val text: String)

/** .rpy 스크립트에서 대사(say)와 선택지(menu) 문자열을 뽑아낸다. */
object RpyParser {

    private val notSpeaker = setOf(
        "play", "queue", "stop", "show", "hide", "scene", "with", "jump", "call", "label", "menu",
        "define", "default", "image", "transform", "screen", "init", "python", "return", "pause",
        "window", "voice", "renpy", "style", "text", "use", "if", "elif", "else", "while", "for",
        "nvl", "centered", "extend", "translate", "old", "new", "pass", "sound", "add", "key", "on",
        "at", "expression", "camera", "textbutton", "imagebutton", "frame", "vbox", "hbox", "fixed",
        "grid", "bar", "action", "tooltip", "hotspot", "timer", "input", "viewport", "side",
        "mousearea", "layout", "global"
    )

    // python / screen / style 등 들여쓰기 블록은 통째로 건너뛴다
    private val blockStart = Regex("""^\s*(?:init|python|screen|style|transform|translate)\b.*""")

    // [화자] [속성...] "대사" [with ...]
    private val say = Regex(
        """^\s*(?:([A-Za-z_]\w*)((?:\s+[\w@.]+)*)\s+)?"((?:[^"\\]|\\.)*)"(?:\s+(?:with|nointeract|id)\b.*)?(?:\s*#.*)?\s*$"""
    )

    // "선택지" [if 조건]:
    private val choice = Regex(
        """^\s*"((?:[^"\\]|\\.)*)"(?:\s+if\s+.+?)?\s*:\s*(?:#.*)?$"""
    )

    private val ws = Regex("""[ \t]+""")

    fun parse(src: String): List<Line> {
        val out = ArrayList<Line>()
        var skip = -1
        for (raw in src.lineSequence()) {
            val t = raw.trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            val indent = raw.length - raw.trimStart().length
            if (skip >= 0) {
                if (indent > skip) continue else skip = -1
            }
            if (blockStart.matches(raw) && t.endsWith(":")) {
                skip = indent
                continue
            }
            val c = choice.matchEntire(t)
            if (c != null) {
                add(out, "", c.groupValues[1])
                continue
            }
            val m = say.matchEntire(t) ?: continue
            val who = m.groupValues[1]
            if (who.isNotEmpty() && who in notSpeaker) continue
            add(out, who, m.groupValues[3])
        }
        return out
    }

    private fun add(out: MutableList<Line>, who: String, raw: String) {
        val text = unescape(ws.replace(raw, " ")).trim()
        if (text.any { it.isLetter() }) out.add(Line(who, text))
    }

    private fun unescape(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (val n = s[i + 1]) {
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    '\\' -> sb.append('\\')
                    '"' -> sb.append('"')
                    '\'' -> sb.append('\'')
                    else -> sb.append(c).append(n)
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }
}

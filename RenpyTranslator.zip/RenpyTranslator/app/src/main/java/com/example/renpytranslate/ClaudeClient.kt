package com.example.renpytranslate

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class ApiException(val code: Int, message: String) : RuntimeException(message)

class ClaudeClient(
    private val apiKey: String,
    private val model: String,
    guide: String
) {
    private val system = """
You are a professional game localizer translating a Ren'Py visual novel from English into Korean.
$guide
Rules:
- Translate every item in "lines" into natural Korean. "context" holds the preceding lines for reference only; do not translate it.
- Keep every tag and placeholder exactly as written: {i} {/i} {b} {w} {w=0.5} {nw} {fast} {p} {color=#fff} ..., [name] [player!t], %s, %(x)s, %%, {{ and [[ .
- Keep \n line-break escapes as they are.
- Keep character names in their original English spelling.
- Output JSON only, with no explanation and no code fence: {"t":["...", "..."]}
- "t" must contain exactly as many items as "lines", in the same order.
""".trimIndent()

    suspend fun translate(context: List<Line>, lines: List<Line>): List<String> =
        withContext(Dispatchers.IO) {
            val req = JSONObject()
                .put("context", toJson(context))
                .put("lines", toJson(lines))
            val reply = post(req.toString())
            val s = reply.indexOf('{')
            val e = reply.lastIndexOf('}')
            if (s < 0 || e < s) throw IOException("번역 결과 형식 오류")
            val arr = JSONObject(reply.substring(s, e + 1)).getJSONArray("t")
            if (arr.length() != lines.size) throw IOException("번역 개수 불일치")
            List(lines.size) { arr.getString(it) }
        }

    private fun toJson(list: List<Line>): JSONArray {
        val a = JSONArray()
        for (l in list) a.put(JSONObject().put("s", l.speaker).put("x", l.text))
        return a
    }

    private fun post(userContent: String): String {
        var attempt = 0
        while (true) {
            try {
                val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 30_000
                conn.readTimeout = 180_000
                conn.doOutput = true
                conn.setRequestProperty("x-api-key", apiKey)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
                conn.setRequestProperty("content-type", "application/json")
                val body = JSONObject()
                    .put("model", model)
                    .put("max_tokens", 8000)
                    .put("system", system)
                    .put(
                        "messages",
                        JSONArray().put(JSONObject().put("role", "user").put("content", userContent))
                    )
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                conn.disconnect()
                if (code in 200..299) {
                    val content = JSONObject(text).getJSONArray("content")
                    val sb = StringBuilder()
                    for (i in 0 until content.length()) {
                        val b = content.getJSONObject(i)
                        if (b.optString("type") == "text") sb.append(b.optString("text"))
                    }
                    return sb.toString()
                }
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                    .getOrDefault(text.take(200))
                if ((code == 429 || code >= 500) && attempt < 4) {
                    attempt++
                    Thread.sleep(2000L * attempt)
                    continue
                }
                throw ApiException(code, "API 오류 $code: $msg")
            } catch (e: IOException) {
                if (attempt >= 4) throw e
                attempt++
                Thread.sleep(2000L * attempt)
            }
        }
    }
}

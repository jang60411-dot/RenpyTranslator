package com.example.renpytranslate

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var keyEdit: EditText
    private lateinit var modelEdit: EditText
    private lateinit var guideEdit: EditText
    private lateinit var folderText: TextView
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var bar: ProgressBar
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button

    private var treeUri: Uri? = null
    private var job: Job? = null
    private val logLines = ArrayDeque<String>()

    private val pickFolder =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                setTree(uri)
            }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("rt", Context.MODE_PRIVATE)

        val pad = dp(16)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply {
            text = t
            setPadding(0, dp(14), 0, dp(4))
        }

        col.addView(TextView(this).apply { text = "렌파이 게임 한국어 번역기"; textSize = 20f })

        col.addView(label("Anthropic API 키"))
        keyEdit = EditText(this).apply {
            hint = "sk-ant-..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        col.addView(keyEdit)

        col.addView(label("모델 (비우면 기본값)"))
        modelEdit = EditText(this).apply { setText(prefs.getString("model", DEFAULT_MODEL)) }
        col.addView(modelEdit)

        col.addView(label("번역 지침 (말투 등)"))
        guideEdit = EditText(this).apply {
            setText(prefs.getString("guide", DEFAULT_GUIDE))
            minLines = 2
        }
        col.addView(guideEdit)

        col.addView(label("게임 폴더 (game 폴더가 들어있는 폴더, 또는 game 폴더)"))
        folderText = TextView(this).apply { text = "선택 안 됨" }
        col.addView(folderText)
        col.addView(Button(this).apply {
            text = "게임 폴더 선택"
            setOnClickListener { pickFolder.launch(null) }
        })

        startBtn = Button(this).apply { text = "번역 시작"; setOnClickListener { start() } }
        stopBtn = Button(this).apply {
            text = "중지"
            isEnabled = false
            setOnClickListener { job?.cancel() }
        }
        col.addView(startBtn)
        col.addView(stopBtn)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        col.addView(bar)
        status = TextView(this).apply { text = "대기 중" }
        col.addView(status)
        logView = TextView(this).apply { setPadding(0, dp(12), 0, 0) }
        col.addView(logView)

        setContentView(ScrollView(this).apply { addView(col) })

        prefs.getString("tree", null)?.let { setTree(Uri.parse(it)) }
    }

    private fun setTree(uri: Uri) {
        treeUri = uri
        prefs.edit().putString("tree", uri.toString()).apply()
        folderText.text = Uri.decode(uri.lastPathSegment ?: uri.toString())
    }

    private fun setRunning(r: Boolean) {
        startBtn.isEnabled = !r
        stopBtn.isEnabled = r
        if (r) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun addLog(msg: String) = runOnUiThread {
        logLines.addLast(msg)
        while (logLines.size > 14) logLines.removeFirst()
        logView.text = logLines.joinToString("\n")
    }

    private fun onProgress(done: Int, total: Int) = runOnUiThread {
        bar.max = total
        bar.progress = done
        status.text = "$done / $total"
    }

    private fun start() {
        val key = keyEdit.text.toString().trim()
        val uri = treeUri
        if (key.isEmpty()) {
            Toast.makeText(this, "API 키를 입력해 주세요", Toast.LENGTH_SHORT).show()
            return
        }
        if (uri == null) {
            Toast.makeText(this, "게임 폴더를 먼저 선택해 주세요", Toast.LENGTH_SHORT).show()
            return
        }
        val model = modelEdit.text.toString().trim().ifEmpty { DEFAULT_MODEL }
        val guide = guideEdit.text.toString().trim().ifEmpty { DEFAULT_GUIDE }
        prefs.edit().putString("key", key).putString("model", model).putString("guide", guide).apply()

        setRunning(true)
        val client = ClaudeClient(key, model, guide)
        job = lifecycleScope.launch {
            try {
                TranslateJob(applicationContext, uri, client, ::addLog, ::onProgress).run()
            } catch (e: CancellationException) {
                addLog("중지했어요. 다시 시작하면 이어서 번역해요.")
                throw e
            } catch (e: Exception) {
                addLog("❌ ${e.message}")
            } finally {
                setRunning(false)
            }
        }
    }

    companion object {
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
        const val DEFAULT_GUIDE = "자연스러운 한국어 반말(구어체)로 번역해. 캐릭터의 성격과 분위기를 살려줘."
    }
}
